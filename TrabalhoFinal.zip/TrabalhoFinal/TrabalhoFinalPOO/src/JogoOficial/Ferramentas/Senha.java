package JogoOficial.Ferramentas;

import basicas.Ferramenta;

public class Senha extends Ferramenta{
    public Senha(){
        super("Senha");
    }

    @Override
    public boolean usar(){
        return true;
    }
}
