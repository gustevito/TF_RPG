package JogoOficial.Ferramentas;

import basicas.Ferramenta;

public class PapelPlastificado extends Ferramenta {
    public PapelPlastificado(){
        super("Papel Plastificado");
    }

    public boolean usar(){
        return true;
    }
}
