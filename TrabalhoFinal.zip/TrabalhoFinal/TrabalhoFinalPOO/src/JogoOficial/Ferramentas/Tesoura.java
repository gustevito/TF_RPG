package JogoOficial.Ferramentas;

import basicas.Ferramenta;

public class Tesoura extends Ferramenta {
    public Tesoura(){
        super("Tesoura");
    }

    @Override
    public boolean usar(){
        return true;
    }
}
