package JogoOficial.Ferramentas;

import basicas.Ferramenta;

public class Papel extends Ferramenta{
    public Papel(){
        super("Papel");

    }

    @Override
    public boolean usar(){
        return true;
    }
}
