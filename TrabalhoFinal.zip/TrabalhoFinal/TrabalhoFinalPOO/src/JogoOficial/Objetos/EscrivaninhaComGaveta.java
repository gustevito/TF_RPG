package JogoOficial.Objetos;

public class EscrivaninhaComGaveta {
    
}
