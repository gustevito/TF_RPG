package JogoOficial.Objetos;

public class ArmarioPequeno {
    
}
