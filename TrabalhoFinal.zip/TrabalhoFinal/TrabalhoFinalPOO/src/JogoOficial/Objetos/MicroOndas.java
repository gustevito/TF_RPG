package JogoOficial.Objetos;

public class MicroOndas {
    
}
