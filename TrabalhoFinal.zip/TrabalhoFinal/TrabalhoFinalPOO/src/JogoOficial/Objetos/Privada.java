package JogoOficial.Objetos;

public class Privada {
    
}
