package JogoOficial.Objetos;

public class Gavetas {
    
}
