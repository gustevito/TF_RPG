package JogoOficial.Objetos;

public class PastaDeFolhas {
    
}
