package JogoOficial.Objetos;

public class Computador {
    
}
