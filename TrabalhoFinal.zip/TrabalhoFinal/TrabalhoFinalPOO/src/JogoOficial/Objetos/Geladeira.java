package JogoOficial.Objetos;

public class Geladeira {
    
}
