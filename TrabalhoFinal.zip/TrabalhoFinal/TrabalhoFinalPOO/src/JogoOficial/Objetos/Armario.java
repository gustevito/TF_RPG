package JogoOficial.Objetos;

import JogoOficial.Ferramentas.Tesoura;
import basicas.Ferramenta;
import basicas.Objeto;

public class Armario extends Objeto {
    
}
