package JogoOficial.Objetos;

public class Janela {
    
}
