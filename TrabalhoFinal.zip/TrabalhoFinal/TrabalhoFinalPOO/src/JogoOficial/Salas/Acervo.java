package JogoOficial.Salas;

public class Acervo {
    
}
