package JogoOficial.Salas;

public class Banheiro {
    
}
