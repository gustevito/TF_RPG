package JogoOficial.Salas;

public class Refeitorio {
    
}
