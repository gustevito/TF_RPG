package JogoOficial.Salas;

public class SalaDoCeo {
    
}
