package JogoOficial.Salas;

public class SalaDeReunioes {
    
}
