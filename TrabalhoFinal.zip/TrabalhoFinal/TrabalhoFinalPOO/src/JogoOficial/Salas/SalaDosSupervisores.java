package JogoOficial.Salas;

public class SalaDosSupervisores {
    
}
